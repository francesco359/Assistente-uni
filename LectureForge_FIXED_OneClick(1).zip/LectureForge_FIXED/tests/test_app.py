from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)
def test_health(): assert c.get('/health').json()=={'status':'ok'}
def test_frontend(): assert 'LectureForge' in c.get('/').text
def test_flow():
 course=c.post('/api/courses',json={'name':'Statistica'}).json(); assert course['id']
 files=[('files',('lezione.txt',b'La media aritmetica e una misura di posizione. La mediana divide la distribuzione in due parti. L indice di Gini misura la concentrazione del reddito. La curva di Lorenz rappresenta quote cumulate della popolazione e del reddito.','text/plain'))]
 r=c.post('/api/upload',data={'course_id':course['id'],'kind':'transcript'},files=files); assert r.status_code==200
 r=c.post('/api/generate',json={'course_id':course['id'],'title':'Test','count':5}); assert r.status_code==200 and set(r.json())=={'map','quiz','flashcards'}
