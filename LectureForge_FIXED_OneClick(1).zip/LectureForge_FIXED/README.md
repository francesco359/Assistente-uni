# LectureForge FIXED

## Avvio più semplice
- **Windows:** doppio clic su `START_WINDOWS.bat`
- **macOS:** doppio clic su `START_MAC.command` (al primo avvio: tasto destro → Apri)
- **Linux:** `./start_linux.sh`

Il launcher crea automaticamente `.venv`, installa i pacchetti, apre il browser e avvia l'app su `http://127.0.0.1:8000`.

> GitHub non esegue un backend FastAPI. Aprire `README.md` o `index.html` non avvia l'app. Serve il launcher locale oppure un servizio di hosting.

## Pubblicazione online con Render
1. Carica questa cartella in un repository GitHub.
2. Su Render scegli **New → Blueprint**.
3. Collega il repository: Render legge `render.yaml` e crea il servizio.
4. Al termine usa l'URL `https://...onrender.com`.

## Docker
`docker compose up --build`, poi apri `http://localhost:8000`.

## Chat AI pregresse
Seleziona **Chat AI precedenti** e carica JSON, TXT, HTML o ZIP esportati da ChatGPT, Claude o Copilot.

## Limiti MVP
- Audio/video devono essere prima trascritti oppure collegati ad Azure AI Speech.
- PDF scansionati richiedono OCR.
- Il generatore locale è estrattivo. Per mappe della qualità avanzata collega un LLM con output JSON strutturati.
