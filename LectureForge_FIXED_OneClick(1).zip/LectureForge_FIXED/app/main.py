from __future__ import annotations
import json,re,sqlite3,uuid,zipfile,html
from pathlib import Path
from fastapi import FastAPI,UploadFile,File,Form,HTTPException,Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from pypdf import PdfReader
from docx import Document
from pptx import Presentation
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data'; UP=DATA/'uploads'; DATA.mkdir(exist_ok=True); UP.mkdir(exist_ok=True); DB=DATA/'lectureforge.db'
app=FastAPI(title='LectureForge'); app.mount('/static',StaticFiles(directory=ROOT/'app/static'),name='static'); tpl=Jinja2Templates(directory=ROOT/'app/templates')
def con(): c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 c=con(); c.executescript('''CREATE TABLE IF NOT EXISTS courses(id TEXT PRIMARY KEY,name TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,course_id TEXT,name TEXT,kind TEXT,text TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);CREATE TABLE IF NOT EXISTS artifacts(id TEXT PRIMARY KEY,course_id TEXT,kind TEXT,title TEXT,payload TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);'''); c.commit(); c.close()
init()
class Course(BaseModel): name:str
class Gen(BaseModel): course_id:str; title:str='Materiale di studio'; count:int=20
def clean(s): return re.sub(r'\s+',' ',s or '').strip()
def extract(p:Path):
 e=p.suffix.lower()
 if e in {'.txt','.md','.csv','.json','.html'}: return p.read_text(errors='ignore')
 if e=='.pdf': return '\n'.join(x.extract_text() or '' for x in PdfReader(str(p)).pages)
 if e=='.docx': return '\n'.join(x.text for x in Document(str(p)).paragraphs)
 if e=='.pptx': return '\n'.join(sh.text for sl in Presentation(str(p)).slides for sh in sl.shapes if hasattr(sh,'text'))
 if e=='.xlsx':
  wb=load_workbook(p,data_only=True,read_only=True); return '\n'.join(f'{ws.title}: '+' | '.join('' if v is None else str(v) for v in row) for ws in wb.worksheets for row in ws.iter_rows(values_only=True))
 if e=='.zip':
  with zipfile.ZipFile(p) as z: return '\n'.join(z.read(n).decode(errors='ignore') for n in z.namelist() if n.lower().endswith(('.txt','.md','.json','.html','.csv')))
 raise ValueError(f'Formato non supportato: {e}')
def chat(text):
 try:
  obj=json.loads(text); out=[]
  def walk(v):
   if isinstance(v,dict):
    role=v.get('role') or v.get('author') or v.get('sender') or 'messaggio'; content=v.get('content') or v.get('text') or v.get('message')
    if isinstance(content,str): out.append(f'{role}: {content}')
    for x in v.values(): walk(x)
   elif isinstance(v,list):
    for x in v: walk(x)
  walk(obj); return '\n'.join(dict.fromkeys(out)) or text
 except: return re.sub('<[^>]+>',' ',text)
def alltext(cid):
 c=con(); r=c.execute('SELECT text FROM sources WHERE course_id=? ORDER BY created_at',(cid,)).fetchall(); c.close(); return '\n'.join(x['text'] for x in r)
def sents(t): return [clean(x) for x in re.split(r'(?<=[.!?])\s+|\n+',t) if len(clean(x))>40]
def keys(t,n=35):
 from collections import Counter
 stop=set('della delle degli che per con sono come anche questo questa nella nelle alla dalla non una uno del dei un il la le gli e o a da in di su si tra più'.split()); ws=re.findall(r"[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'-]{3,}",t.lower()); return [w for w,_ in Counter(w for w in ws if w not in stop).most_common(n)]
def concept_map(t,title):
 ss=sents(t); out=[]
 for k in keys(t,12):
  rs=[x for x in ss if k in x.lower()][:4]; out.append({'title':k.title(),'simple':rs[0] if rs else k,'details':rs[1:]})
 return {'title':title,'nodes':out}
def cards(t):
 ss=sents(t); return [{'front':f'Che cosa devi ricordare su {k}?','back':next((x for x in ss if k in x.lower()),k)} for k in keys(t,24)]
def quiz(t,n):
 ss=sents(t); kk=keys(t,max(35,n+5)); out=[]
 for i,k in enumerate(kk):
  hit=next((x for x in ss if k in x.lower()),None)
  if not hit: continue
  ds=[x.title() for x in kk if x!=k][:2]; opts=[k.title()]+ds; shift=i%3; opts=opts[shift:]+opts[:shift]
  out.append({'q':f'Quale concetto è descritto? “{hit[:240]}”','options':opts,'answer':opts.index(k.title()),'why':f'Il passaggio richiama direttamente il concetto {k}.'})
  if len(out)>=n: break
 return out
def save(cid,kind,title,payload):
 i=str(uuid.uuid4()); c=con(); c.execute('INSERT INTO artifacts VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)',(i,cid,kind,title,json.dumps(payload,ensure_ascii=False))); c.commit(); c.close(); return i
@app.get('/',response_class=HTMLResponse)
def home(req:Request):
 c=con(); cs=c.execute('SELECT * FROM courses ORDER BY created_at DESC').fetchall(); c.close(); return tpl.TemplateResponse(request=req,name='index.html',context={'courses':cs})
@app.post('/api/courses')
def course(x:Course):
 i=str(uuid.uuid4()); c=con(); c.execute('INSERT INTO courses(id,name) VALUES(?,?)',(i,x.name)); c.commit(); c.close(); return {'id':i,'name':x.name}
@app.get('/api/courses/{cid}')
def course_info(cid:str):
 c=con(); src=[dict(x) for x in c.execute('SELECT id,name,kind,created_at FROM sources WHERE course_id=? ORDER BY created_at DESC',(cid,))]; art=[dict(x) for x in c.execute('SELECT id,title,kind,created_at FROM artifacts WHERE course_id=? ORDER BY created_at DESC',(cid,))]; c.close(); return {'sources':src,'artifacts':art}
@app.post('/api/upload')
async def upload(course_id:str=Form(...),kind:str=Form('document'),files:list[UploadFile]=File(...)):
 result=[]
 for f in files:
  p=UP/f'{uuid.uuid4()}_{Path(f.filename).name}'; p.write_bytes(await f.read())
  try: text=extract(p); text=chat(text) if kind=='chat' else text
  except Exception as e: raise HTTPException(400,str(e))
  i=str(uuid.uuid4()); c=con(); c.execute('INSERT INTO sources(id,course_id,name,kind,text) VALUES(?,?,?,?,?)',(i,course_id,f.filename,kind,text)); c.commit(); c.close(); result.append({'name':f.filename,'chars':len(text)})
 return result
@app.post('/api/generate')
def generate(x:Gen):
 t=alltext(x.course_id)
 if len(t)<100: raise HTTPException(400,'I file non contengono testo sufficiente. Per scansioni serve OCR; per audio serve trascrizione.')
 return {'map':save(x.course_id,'map',x.title,concept_map(t,x.title)),'quiz':save(x.course_id,'quiz',x.title,quiz(t,max(5,min(x.count,50)))),'flashcards':save(x.course_id,'flashcards',x.title,cards(t))}
@app.get('/artifact/{aid}',response_class=HTMLResponse)
def artifact(req:Request,aid:str):
 c=con(); r=c.execute('SELECT * FROM artifacts WHERE id=?',(aid,)).fetchone(); c.close()
 if not r: raise HTTPException(404)
 a=dict(r); a['payload']=json.loads(a['payload']); return tpl.TemplateResponse(request=req,name='artifact.html',context={'a':a})
@app.get('/health')
def health(): return {'status':'ok'}
