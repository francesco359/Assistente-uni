import os,sys,subprocess,time,webbrowser,venv
from pathlib import Path
ROOT=Path(__file__).resolve().parent; V=ROOT/'.venv'; py=V/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
if not py.exists():
 print('Prima configurazione: creo ambiente e installo dipendenze...'); venv.create(V,with_pip=True); subprocess.check_call([str(py),'-m','pip','install','--upgrade','pip']); subprocess.check_call([str(py),'-m','pip','install','-r',str(ROOT/'requirements.txt')])
url='http://127.0.0.1:8000'; print('LectureForge in avvio su',url); time.sleep(1); webbrowser.open(url)
os.execv(str(py),[str(py),'-m','uvicorn','app.main:app','--host','127.0.0.1','--port','8000'])
